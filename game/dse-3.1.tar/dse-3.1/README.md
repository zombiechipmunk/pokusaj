# dse
Dating Sim Engine for Ren'Py
The Dating Sim Engine (DSE) is a framework for writing games based on events that are triggered by statistics. It comprises a number of independent modules that can be combined to create games. 
