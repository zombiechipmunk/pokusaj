description = "A game that demonstrates the use of the dating-sim engine. A non-graphical proof of concept."
ro = True
